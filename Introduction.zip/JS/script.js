// https://github.com/TheKhoshhal?tab=repositories

const profileImg = document.querySelector(".profile-img");

profileImg.addEventListener("click", () => {
  window.open("https://github.com/TheKhoshhal?tab=repositories", "_blank");
});

const githubIcon = document.querySelector(".github-icon");
const telegramIcon = document.querySelector(".telegram-icon");

githubIcon.addEventListener("click", () =>
  window.open("https://github.com/TheKhoshhal?tab=repositories", "_blank")
);
telegramIcon.addEventListener("click", () =>
  window.open("https://t.me/TheKhoshhal", "_blank")
);
