# CalculatorJS

It's a simple calculator that you can use to do whatever you want
Nothing more to add
Have fun using it 👍
